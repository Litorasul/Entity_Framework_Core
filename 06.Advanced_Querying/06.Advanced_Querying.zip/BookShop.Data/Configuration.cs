﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-7JEJ5UL\SQLEXPRESS01;Database=BookShop;Integrated Security=True;";
    }
}

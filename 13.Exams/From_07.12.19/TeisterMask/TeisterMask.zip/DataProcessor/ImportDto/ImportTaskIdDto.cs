﻿namespace TeisterMask.DataProcessor.ImportDto
{
    public class ImportTaskIdDto
    {
        public int Id { get; set; }
    }
}